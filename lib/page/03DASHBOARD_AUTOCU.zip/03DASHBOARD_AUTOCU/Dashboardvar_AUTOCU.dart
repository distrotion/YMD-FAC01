import 'dart:async';

class Dashboardvar_AUTOCU {
  static bool iscontrol = false;
  static String selectedDate = '';
  static String SetPartName = '';

  // static late Timer DHtimer;
}
